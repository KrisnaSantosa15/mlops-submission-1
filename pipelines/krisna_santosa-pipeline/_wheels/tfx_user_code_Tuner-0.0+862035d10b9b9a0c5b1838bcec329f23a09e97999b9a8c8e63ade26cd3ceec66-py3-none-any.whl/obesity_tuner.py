import tensorflow as tf
import tensorflow_transform as tft
from tensorflow.keras import layers
from tfx.components.trainer.fn_args_utils import FnArgs
from keras_tuner import RandomSearch, HyperParameters

from keras_tuner.engine.base_tuner import BaseTuner

class CustomTuner(BaseTuner):
    def __init__(self, tuner):
        super().__init__(oracle=tuner.oracle, hypermodel=tuner.hypermodel)
        self.tuner = tuner
        self.fit_kwargs = {}  # Pastikan fit_kwargs ada

    def search(self, *args, **kwargs):
        self.fit_kwargs = kwargs  # Simpan fit_kwargs yang diteruskan
        self.tuner.search(*args, **kwargs)

    def get_best_hyperparameters(self, *args, **kwargs):
        return self.tuner.get_best_hyperparameters(*args, **kwargs)

    def get_best_models(self, *args, **kwargs):
        return self.tuner.get_best_models(*args, **kwargs)

NUMERIC_FEATURES = ['Age', 'Height', 'Weight', 'FCVC', 'NCP', 'CH2O', 'FAF', 'TUE']
CATEGORICAL_FEATURES = ['Gender', 'family_history', 'FAVC', 'CAEC', 'SMOKE', 'SCC', 'CALC', 'MTRANS']
LABEL_KEY = "Obesity"

def _input_fn(file_pattern, tf_transform_output, batch_size=32):
    """Load dataset and apply preprocessing."""
    def _parse_tfrecord_fn(record):
        # Parse the record into features
        feature_spec = tf_transform_output.transformed_feature_spec()
        return tf.io.parse_single_example(record, feature_spec)

    dataset = tf.data.TFRecordDataset(file_pattern)
    dataset = dataset.map(_parse_tfrecord_fn)
    dataset = dataset.batch(batch_size).prefetch(tf.data.AUTOTUNE)
    return dataset

def transformed_name(key):
    return key + '_xf'

def tuner_fn(fn_args: FnArgs):
    """Build the tuner to find the best hyperparameters."""
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)
    
    train_dataset = _input_fn(fn_args.train_files, tf_transform_output, batch_size=32)
    eval_dataset = _input_fn(fn_args.eval_files, tf_transform_output, batch_size=32)

    # Define the hyperparameter search space
    hp = HyperParameters()
    hp.Int('num_hidden_layers', 2, 4)
    hp.Int('embedding_dim', 8, 32, step=8)
    hp.Int('dense_units', 32, 256, step=32)
    hp.Float('dropout_rate', 0.1, 0.5, step=0.1)
    hp.Float('learning_rate', 1e-4, 1e-2, sampling='log')
    hp.Int('batch_size', 32, 128, step=32)
    
    # Create a tuner
    tuner = RandomSearch(
        hypermodel=lambda hp: model_builder(hp, tf_transform_output),
        objective='val_accuracy',
        max_trials=10,
        directory=fn_args.working_dir,
        project_name='obesity_tuning',
        hyperparameters=hp
    )
    
    # Set the search space for datasets
    tuner.search_space_summary()

    # Run the tuner
    tuner.search(
        train_dataset,
        validation_data=eval_dataset,
        epochs=5,
        steps_per_epoch=fn_args.train_steps,
        validation_steps=fn_args.eval_steps
    )
    
    return tuner

def model_builder(hp, tf_transform_output):
    """Build the model for hyperparameter tuning."""
    inputs = tf.keras.layers.Input(shape=(10,))  # Sesuaikan dengan data Anda
    x = inputs

    for _ in range(hp.get('num_hidden_layers')):
        x = tf.keras.layers.Dense(hp.get('dense_units'), activation='relu')(x)
        x = tf.keras.layers.Dropout(hp.get('dropout_rate'))(x)
    
    outputs = tf.keras.layers.Dense(1, activation='sigmoid')(x)
    model = tf.keras.Model(inputs=inputs, outputs=outputs)
    
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=hp.get('learning_rate')),
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    return model
