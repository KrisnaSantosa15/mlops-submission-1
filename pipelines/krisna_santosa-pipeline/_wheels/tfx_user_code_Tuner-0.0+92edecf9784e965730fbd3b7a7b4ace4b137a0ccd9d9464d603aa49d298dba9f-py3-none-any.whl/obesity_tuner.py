import tensorflow as tf
import tensorflow_transform as tft
from tensorflow.keras import layers
from tfx.components.trainer.fn_args_utils import FnArgs
import keras_tuner as kt
from collections import namedtuple

NUMERIC_FEATURES = ['Age', 'Height', 'Weight', 'FCVC', 'NCP', 'CH2O', 'FAF', 'TUE']
CATEGORICAL_FEATURES = ['Gender', 'family_history', 'FAVC', 'CAEC', 'SMOKE', 'SCC', 'CALC', 'MTRANS']
LABEL_KEY = "Obesity"

def transformed_name(key):
    return key + '_xf'

# Define a namedtuple for compatibility with TFX
TunerFnResult = namedtuple('TunerFnResult', ['tuner'])

def tuner_fn(fn_args: FnArgs):
    """Build the tuner to find the best hyperparameters."""
    
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)

    def build_model(hp):
        return model_builder(hp, tf_transform_output)

    tuner = kt.Hyperband(
        hypermodel=build_model,
        objective='val_accuracy',
        max_epochs=10,
        factor=3,
        directory=fn_args.working_dir,
        project_name='obesity_tuning'
    )
    
    # Wrap the tuner object in a namedtuple
    return TunerFnResult(tuner=tuner)

def model_builder(hp, tf_transform_output):
    """Build model with given hyperparameters."""
    
    inputs = []
    feature_layers = []

    # Numeric features
    for feature_name in NUMERIC_FEATURES:
        numeric_input = layers.Input(
            shape=(1,), name=transformed_name(feature_name))
        inputs.append(numeric_input)
        feature_layers.append(numeric_input)

    # Categorical features
    for feature_name in CATEGORICAL_FEATURES:
        vocab_size = tf_transform_output.vocabulary_size_by_name(feature_name)
        categorical_input = layers.Input(
            shape=(1,), name=transformed_name(feature_name), dtype=tf.int64)
        inputs.append(categorical_input)
        embedding = layers.Embedding(vocab_size, 16)(categorical_input)
        embedding_flat = layers.Flatten()(embedding)
        feature_layers.append(embedding_flat)

    # Concatenate features
    features = layers.concatenate(feature_layers)

    # Hidden layers
    features = layers.Dense(hp.Int('dense_units', 64, 256, step=64), activation='relu')(features)
    features = layers.Dropout(hp.Float('dropout_rate', 0.2, 0.5, step=0.1))(features)

    outputs = layers.Dense(7, activation='softmax')(features)
    model = tf.keras.Model(inputs=inputs, outputs=outputs)

    model.compile(
        optimizer=tf.keras.optimizers.Adam(hp.Float('learning_rate', 1e-4, 1e-2, sampling='log')),
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model
